// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
var app = angular.module('starter', ['ionic', 'ui.router'])
.config(function($stateProvider, $urlRouterProvider){
  $stateProvider
    .state('home', {
      controller: 'topController',
      templateUrl: 'views/home.html',
      url: '/',
    })
    .state('about', {
      controller: 'topController',
      templateUrl: 'views/about.html',
      url: '/sobre',
    })
    .state('estrategiaempresarial', {
      controller: 'topController',
      templateUrl: 'views/estrategiaempresarial.html',
      url: '/estrategiaempresarial',
    })
    .state('menu',{
      controller: 'topController',
      templateUrl: 'views/menu.html',
      url: 'menu',
    })
    .state('servicos',{
      controller: 'topController',
      templateUrl: 'views/servicos.html',
      url: 'servicos',
    })
    .state('diagnosticofiscal_1',{
      controller: 'topController',
      templateUrl: 'views/diagnosticofiscal_1.html',
      url: 'diagnosticofiscal_1',
    })
    .state('diagnosticofiscal_2',{
      controller: 'topController',
      templateUrl: 'views/diagnosticofiscal_2.html',
      url: 'diagnosticofiscal_2',
    })
    .state('diagnosticofiscal_3',{
      controller: 'topController',
      templateUrl: 'views/diagnosticofiscal_3.html',
      url: 'diagnosticofiscal_3',
    })
    .state('relacoessocietarias1',{
      controller: 'topController',
      templateUrl: 'views/relacoessocietarias1.html',
      url: 'relacoessocietarias1',
    })
    .state('relacoessocietarias2',{
      controller: 'topController',
      templateUrl: 'views/relacoessocietarias2.html',
      url: 'relacoessocietarias2',
    })
    .state('auditoriacontabil',{
      controller: 'topController',
      templateUrl: 'views/auditoriacontabil.html',
      url: 'auditoriacontabil',
    })
    .state('controlesinternos',{
      controller: 'topController',
      templateUrl: 'views/controlesinternos.html',
      url: 'controlesinternos',
    })
    .state('consultoriaempresarial',{
      controller: 'topController',
      templateUrl: 'views/consultoriaempresarial.html',
      url: 'consultoriaempresarial',
    })
    .state('assuntostributarios',{
      controller: 'topController',
      templateUrl: 'views/assuntostributarios.html',
      url: 'assuntostributarios',
    })
    .state('relacoesdotrabalho',{
      controller: 'topController',
      templateUrl: 'views/relacoesdotrabalho.html',
      url: 'relacoesdotrabalho',
    })
    .state('relacoescomgoverno',{
      controller: 'topController',
      templateUrl: 'views/relacoescomgoverno.html',
      url: 'relacoescomgoverno',
    })
    .state('relacoesdeconsumo',{
      controller: 'topController',
      templateUrl: 'views/relacoesdeconsumo.html',
      url: 'relacoesdeconsumo',
    })
    .state('desenvolvimentoprofissional',{
      controller: 'topController',
      templateUrl: 'views/desenvolvimentoprofissional.html',
      url: 'desenvolvimentoprofissional',
    })
    .state('metodologia',{
      controller: 'topController',
      templateUrl: 'views/metodologia.html',
      url: 'metodologia',
    })
    .state('grupo',{
      controller: 'grupoController',
      templateUrl: 'views/grupo.html',
      url: 'grupo',
    })
    .state('socios',{
      controller: 'sociosController',
      templateUrl: 'views/socios.html',
      url: 'socios',
    })
    .state('contato',{
      templateUrl: 'views/contato.html',
      url: 'contato',
    })
  ;
  $urlRouterProvider.otherwise('/');
})
.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
