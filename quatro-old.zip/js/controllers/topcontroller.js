app.controller('topController', function($scope, $window){
  console.log('in topController');

$window.scrollTo(0,0);
});
