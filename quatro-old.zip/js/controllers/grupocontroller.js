app.controller('grupoController', function($scope, $window){
  console.log('in grupoController');
  $scope.expandgrupo1 = false;
  $scope.expandgrupo2 = false;

  $scope.clickgrupo1 = function (){
    if(  $scope.expandgrupo1 == true)
    {
          $scope.expandgrupo1 = false;
    }
    else {
      $scope.expandgrupo1 = true;
      $scope.expandgrupo2 = false;
    }

  };

  $scope.clickgrupo2 = function (){
    if(  $scope.expandgrupo2 == true)
    {
          $scope.expandgrupo2 = false;
    }
    else if ($scope.expandgrupo1) {
      $scope.expandgrupo2 = true;
      $scope.expandgrupo1 = false;
      $window.scrollTo(0,0);
    }
    else {
      $scope.expandgrupo1 = false;
      $scope.expandgrupo2 = true;
    }

  };
})
