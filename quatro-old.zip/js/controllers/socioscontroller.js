app.controller('sociosController', function($scope, $window){
  console.log('in sociosController');
  $scope.expandpartner1 = false;
  $scope.expandpartner2 = false;

  $scope.clickpartner1 = function (){
    if(  $scope.expandpartner1 == true)
    {
          $scope.expandpartner1 = false;
    }
    else {
      $scope.expandpartner1 = true;
      $scope.expandpartner2 = false;
    }

  };

  $scope.clickpartner2 = function (){
    if(  $scope.expandpartner2 == true)
    {
          $scope.expandpartner2 = false;
    }
    else if ($scope.expandpartner1) {
      $scope.expandpartner2 = true;
      $scope.expandpartner1 = false;
      $window.scrollTo(0,0);
    }
    else {
      $scope.expandpartner1 = false;
      $scope.expandpartner2 = true;
    }

  };
})
